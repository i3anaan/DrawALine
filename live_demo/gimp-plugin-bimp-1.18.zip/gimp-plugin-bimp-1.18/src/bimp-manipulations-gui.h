#ifndef __BIMP_MANIPULATIONS_GUI_H__
#define __BIMP_MANIPULATIONS_GUI_H__

#include <gtk/gtk.h>
#include "bimp-manipulations.h"

void bimp_open_editwindow(manipulation, gboolean); 

#endif
